Title: CST8244 Assignment 1 - Door Entry System

@author Sahil Kakadiya
@author Meet Kotadiya

Contribution: We both worked on everything together, using Git and extreme programming techniques.

Status: The program meets all of the requirements, provides the same output as the reference screenshots. 
	It runs and behaves as expected, and does not terminate unexpectedly. There are no missing requirements.

Known Issues: None.

Expected Grade: 100%
