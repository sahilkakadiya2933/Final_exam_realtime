# Title {passing data between calc_server and calc_client

## Status : running good
 
 ## Known Issues {There are no known issues.} 
 
 ## Expected Grade {80%} 