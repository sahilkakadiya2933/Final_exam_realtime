Title Lab 7 (Another Simple Resource Manager)

Author
kaka0030@algonquinlive.com

Status
Working Condition good

Known Issues
No issue found

Expected Grade
Full Grade