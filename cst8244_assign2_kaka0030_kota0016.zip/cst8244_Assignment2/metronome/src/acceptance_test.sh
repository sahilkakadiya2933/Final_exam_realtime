#!/bin/ksh

echo "Starting acceptance tests..."

# Launch the metronome with initial parameters
./metronome 120 2 4 &
METRONOME_PID=$!
sleep 3

# Check current metronome settings
echo "Verifying: cat /dev/local/metronome"
cat /dev/local/metronome
echo ""

# Check metronome help information
echo "Verifying: cat /dev/local/metronome-help"
cat /dev/local/metronome-help
echo ""

# Modify the metronome configuration
echo "Verifying: echo set 100 2 4 > /dev/local/metronome"
echo "set 100 2 4" > /dev/local/metronome
sleep 3
cat /dev/local/metronome
echo ""

# Modify the metronome configuration again
echo "Verifying: echo set 200 5 4 > /dev/local/metronome"
echo "set 200 5 4" > /dev/local/metronome
sleep 3
cat /dev/local/metronome
echo ""

# Stop the metronome
echo "Verifying: echo stop > /dev/local/metronome"
echo "stop" > /dev/local/metronome
sleep 1

# Restart the metronome
echo "Verifying: echo start > /dev/local/metronome"
echo "start" > /dev/local/metronome
sleep 3
cat /dev/local/metronome
echo ""

# Pause the metronome for 3 seconds
echo "Verifying: echo pause 3 > /dev/local/metronome"
echo "pause 3" > /dev/local/metronome
sleep 4

# Test pause with 10 seconds
echo "Verifying: echo pause 10 > /dev/local/metronome"
echo "pause 10" > /dev/local/metronome
echo ""

# Test invalid command
echo "Verifying: echo bogus > /dev/local/metronome"
echo "bogus" > /dev/local/metronome
echo ""

# Reset the metronome settings
echo "Verifying: echo set 120 2 4 > /dev/local/metronome"
echo "set 120 2 4" > /dev/local/metronome
sleep 3
cat /dev/local/metronome
echo ""

# Display metronome help again
echo "Verifying: cat /dev/local/metronome-help"
cat /dev/local/metronome-help
echo ""

# Attempt to write to the help device (should fail)
echo "Verifying: echo Writes-Not-Allowed > /dev/local/metronome-help"
echo "Writes-Not-Allowed" > /dev/local/metronome-help
echo ""

# Terminate the metronome process
echo "Verifying: echo quit > /dev/local/metronome"
echo "quit" > /dev/local/metronome
sleep 1

# Ensure the metronome has stopped running
if ps -p $METRONOME_PID > /dev/null; then
   echo "Metronome is still active."
else
   echo "Metronome has stopped."
fi

echo "Acceptance tests concluded."
